<footer>
    <p class="mb-0"> &copy; <span data-year></span> {{ $settings->general->site_name }} -
        {{ admin_trans('All rights reserved.') }} | <span class="capitalize">{{ config('system.item.alias') }}</span>
        v{{ config('system.item.version') }}</p>
    <p class="mb-0 ms-auto">{{ admin_trans('Powered by Vironeer') }}</p>
</footer>

<div class="mb-3">
    {!! app('captcha')->display() !!}
    {!! $scripts !!}
</div>

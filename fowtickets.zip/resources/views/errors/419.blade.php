@extends('errors.layout')
@section('title', translate('Page Expired', 'errors'))
@section('code', '419')
@section('message', translate('Page expired error message', 'errors'))

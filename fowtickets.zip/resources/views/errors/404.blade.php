@extends('errors.layout')
@section('title', translate('Page Not Found', 'errors'))
@section('code', '404')
@section('message', translate('Page not found error message', 'errors'))

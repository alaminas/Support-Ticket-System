@extends('errors.layout')
@section('title', translate('Service Unavailable', 'errors'))
@section('code', '503')
@section('message', translate('Service unavailable error message', 'errors'))

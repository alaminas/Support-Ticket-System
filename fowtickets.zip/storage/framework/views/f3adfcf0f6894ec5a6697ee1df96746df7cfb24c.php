<?php $__env->startSection('section', admin_trans('Tickets')); ?>
<?php $__env->startSection('title', admin_trans('New Ticket')); ?>
<?php $__env->startSection('back', route('admin.tickets.index')); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body p-4">
            <form id="vironeer-submited-form" action="<?php echo e(route('admin.tickets.store')); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row g-4 mb-2">
                    <div class="col-lg-12">
                        <label class="form-label"><?php echo e(admin_trans('Subject')); ?></label>
                        <input type="text" name="subject" class="form-control form-control-lg"
                            value="<?php echo e(old('subject')); ?>" autofocus required>
                    </div>
                    <div class="col-lg-4">
                        <label class="form-label"><?php echo e(admin_trans('User')); ?></label>
                        <select name="user" class="form-select form-select-lg selectpicker" data-live-search="true"
                            title="<?php echo e(admin_trans('Choose')); ?>" required>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"
                                    <?php echo e(old('user') == $user->id || request('user') == $user->id ? 'selected' : ''); ?>>
                                    <?php echo e($user->getName()); ?> (<?php echo e($user->email); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-4">
                        <label class="form-label"><?php echo e(admin_trans('Department')); ?></label>
                        <select name="department" class="form-select form-select-lg selectpicker" data-live-search="true"
                            title="<?php echo e(admin_trans('Choose')); ?>" required>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>"
                                    <?php echo e(old('department') == $department->id ? 'selected' : ''); ?>><?php echo e($department->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-4">
                        <label class="form-label"><?php echo e(admin_trans('Priority')); ?></label>
                        <select name="priority" class="form-select form-select-lg" required>
                            <?php $__currentLoopData = \App\Models\Ticket::getPriorityOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e(old('priority') == $key ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-12">
                        <label class="form-label"><?php echo e(admin_trans('Description')); ?></label>
                        <textarea name="description" class="form-control" rows="10" required><?php echo e(old('description')); ?></textarea>
                    </div>
                    <div class="col-lg-12">
                        <div class="attachments">
                            <div class="attachment-box-1">
                                <label class="form-label"><?php echo e(admin_trans('Attachments')); ?></label>
                                <div class="input-group">
                                    <input type="file" name="attachments[]" class="form-control form-control-lg">
                                    <button id="addAttachment" class="btn btn-outline-secondary" type="button">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php $__env->startPush('styles_libs'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts_libs'); ?>
        <script src="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/tickets/create.blade.php ENDPATH**/ ?>
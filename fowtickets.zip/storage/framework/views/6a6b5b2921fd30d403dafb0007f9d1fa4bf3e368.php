<?php
$description = $__env->yieldContent('description') ? $__env->yieldContent('description') : $settings->seo->description ?? '';
$ogImage = $__env->yieldContent('og_image') ? $__env->yieldContent('og_image') : asset($settings->media->social_image);
?>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="ie=edge" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<meta name="theme-color" content="<?php echo e($settings->colors->primary_color); ?>">
<meta name="language" content="<?php echo e(app()->getLocale()); ?>">
<meta name="description" content="<?php echo e($description); ?>">
<meta name="keywords" content="<?php echo e($settings->seo->keywords ?? ''); ?>">
<meta property="og:site_name" content="<?php echo e($settings->general->site_name); ?>">
<meta property="og:locale" content="<?php echo e(app()->getLocale()); ?>">
<meta property="og:locale:alternate" content="<?php echo e(app()->getLocale()); ?>">
<meta property="og:type" content="website">
<meta property="og:title" content="<?php echo e(pageTitle($__env)); ?>">
<meta property="og:description" content="<?php echo e($description); ?>">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e(pageTitle($__env)); ?>">
<meta name="twitter:description" content="<?php echo e($description); ?>">
<meta property="og:image:height" content="600">
<meta property="og:image:width" content="316">
<meta property="og:url" content="<?php echo e(url()->current()); ?>">
<meta property="og:image" content="<?php echo e($ogImage); ?>">
<meta name="twitter:image:src" content="<?php echo e($ogImage); ?>">
<title><?php echo e(pageTitle($__env)); ?></title>
<link rel="icon" href="<?php echo e(asset($settings->media->favicon)); ?>">
<?php echo $__env->make('includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/includes/head.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', admin_trans('PopUp Notice')); ?>
<?php $__env->startSection('container', 'container-max-lg'); ?>
<?php $__env->startSection('content'); ?>
    <form id="vironeer-submited-form" action="<?php echo e(route('admin.extra.notice')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-body my-2">
                <div class="row">
                    <div class="col-lg-2">
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(admin_trans('Status')); ?> </label>
                            <input type="checkbox" name="popup[status]" data-toggle="toggle"
                                <?php echo e($settings->popup->status ? 'checked' : ''); ?>>
                        </div>
                    </div>
                </div>
                <div class="mb-0">
                    <label class="form-label"><?php echo e(admin_trans('PopUp description')); ?> </label>
                    <textarea name="popup[body]" rows="10" class="form-control ckeditor"><?php echo e($settings->popup->body); ?></textarea>
                </div>
            </div>
        </div>
    </form>
    <?php echo $__env->make('admin.includes.ckeditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/extra/popup-notice.blade.php ENDPATH**/ ?>
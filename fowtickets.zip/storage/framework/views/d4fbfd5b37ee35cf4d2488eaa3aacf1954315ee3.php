<?php $__env->startPush('scripts_libs'); ?>
    <?php
        $translation = null;
        $language = getLocale();
        $translationFile = "assets/vendor/libs/ckeditor/translations/{$language}.js";
        if (file_exists(public_path($translationFile))) {
            $translation = $translationFile;
        }
    ?>
<?php if($translation): ?>
<script src="<?php echo e(asset($translationFile)); ?>"></script>
<?php endif; ?>
<script src="<?php echo e(asset('assets/vendor/libs/ckeditor/plugins/uploadAdapterPlugin.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/ckeditor/ckeditor.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/includes/ckeditor.blade.php ENDPATH**/ ?>
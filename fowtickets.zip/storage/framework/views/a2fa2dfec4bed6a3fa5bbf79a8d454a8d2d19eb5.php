<script>
    "use strict";
    const config = <?php echo json_encode([
        'lang' => app()->getLocale(),
        'url' => url('/'),
        'colors' => $settings->colors,
        'translates' => [
            'copied' => translate('Copied to clipboard'),
            'actionConfirm' => translate('Are you sure?'),
        ],
    ]); ?>;
</script>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/includes/config.blade.php ENDPATH**/ ?>
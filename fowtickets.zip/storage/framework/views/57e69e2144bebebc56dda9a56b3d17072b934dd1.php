<nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
        <?php $segments = ''; ?>
        <?php $__currentLoopData = request()->segments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $segments .= '/' . $segment; ?>
            <li class="breadcrumb-item capitalize <?php if(request()->segment(count(request()->segments())) == $segment): ?> active <?php endif; ?>">
                <?php if(request()->segment(count(request()->segments())) != $segment): ?>
                    <a href="<?php echo e(url($segments)); ?>"><?php echo e(ucfirst($segment)); ?></a>
                <?php else: ?>
                    <?php echo e(ucfirst($segment)); ?>

                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</nav>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/partials/breadcrumb.blade.php ENDPATH**/ ?>
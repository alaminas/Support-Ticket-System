<?php $__env->startSection('section', admin_trans('Knowledge base')); ?>
<?php $__env->startSection('title', admin_trans('Categories')); ?>
<?php $__env->startSection('link', route('admin.knowledgebase.categories.create')); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <table class="table datatable w-100">
            <thead>
                <tr>
                    <th class="tb-w-2x">#</th>
                    <th class="tb-w-7x"><?php echo e(admin_trans('Category')); ?></th>
                    <th class="tb-w-3x"><?php echo e(admin_trans('Views')); ?></th>
                    <th class="tb-w-7x"><?php echo e(admin_trans('Published date')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="item">
                        <td><?php echo e($category->id); ?></td>
                        <td>
                            <div class="vironeer-content-box align-items-center">
                                <a class="vironeer-content-image"
                                    href="<?php echo e(route('admin.knowledgebase.categories.edit', $category->id)); ?>">
                                    <img src="<?php echo e(asset($category->icon)); ?>">
                                </a>
                                <div>
                                    <a class="text-reset"
                                        href="<?php echo e(route('admin.knowledgebase.categories.edit', $category->id)); ?>">
                                        <?php echo e($category->name); ?></a>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-dark"><?php echo e($category->views); ?></span></td>
                        <td><?php echo e(dateFormat($category->created_at)); ?></td>
                        <td>
                            <div class="text-end">
                                <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown"
                                    aria-expanded="true">
                                    <i class="fa fa-ellipsis-v fa-sm text-muted"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-sm-end" data-popper-placement="bottom-end">
                                    <li>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('knowledgebase.category', $category->slug)); ?>"
                                            target="_blank"><i class="fa fa-eye me-2"></i><?php echo e(admin_trans('Preview')); ?></a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('admin.knowledgebase.categories.edit', $category->id)); ?>"><i
                                                class="fa fa-edit me-2"></i><?php echo e(admin_trans('Edit')); ?></a>
                                    </li>
                                    <li>
                                        <hr class="dropdown-divider" />
                                    </li>
                                    <li>
                                        <form action="<?php echo e(route('admin.knowledgebase.categories.destroy', $category->id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="action-confirm dropdown-item text-danger"><i
                                                    class="far fa-trash-alt me-2"></i><?php echo e(admin_trans('Delete')); ?></button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/knowledgebase/categories/index.blade.php ENDPATH**/ ?>
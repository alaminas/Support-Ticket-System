<div class="drop-down user-menu ms-3 <?php echo e(isset($margin) ? $margin : ''); ?>" data-dropdown data-dropdown-position="top">
    <div class="drop-down-btn">
        <img src="<?php echo e(auth()->user()->getAvatar()); ?>" alt="<?php echo e(auth()->user()->getName()); ?>" class="user-img">
        <span class="user-name"><?php echo e(auth()->user()->getName()); ?></span>
        <i class="fa fa-angle-down ms-2"></i>
    </div>
    <div class="drop-down-menu">
        <?php if(auth()->user()->isAdmin()): ?>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="drop-down-item">
                <i class="fa-solid fa-table-columns"></i>
                <?php echo e(admin_trans('Admin Panel')); ?>

            </a>
        <?php elseif(auth()->user()->isAgent()): ?>
            <a href="<?php echo e(route('agent.tickets.index')); ?>" class="drop-down-item">
                <i class="fa-solid fa-inbox"></i>
                <?php echo e(translate('Tickets', 'tickets')); ?>

            </a>
            <a href="<?php echo e(route('agent.settings.index')); ?>" class="drop-down-item">
                <i class="fa fa-cog"></i>
                <?php echo e(translate('Settings', 'settings')); ?>

            </a>
        <?php else: ?>
            <a href="<?php echo e(route('user.tickets.index')); ?>" class="drop-down-item">
                <i class="fa-solid fa-inbox"></i>
                <?php echo e(translate('Tickets', 'tickets')); ?>

            </a>
            <a href="<?php echo e(route('user.settings.index')); ?>" class="drop-down-item">
                <i class="fa fa-cog"></i>
                <?php echo e(translate('Settings', 'settings')); ?>

            </a>
        <?php endif; ?>
        <a href="#" class="drop-down-item text-danger"
            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="fa fa-power-off"></i>
            <?php echo e(translate('Logout', 'auth')); ?>

        </a>
    </div>
</div>
<form id="logout-form" class="d-inline" action="<?php echo e(route('logout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
</form>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/partials/user-menu.blade.php ENDPATH**/ ?>
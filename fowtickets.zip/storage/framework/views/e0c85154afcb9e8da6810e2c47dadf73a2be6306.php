<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="ie=edge" />
<meta name="robots" content="noindex, nofollow">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<title><?php echo e(pageTitle($__env)); ?></title>
<link rel="shortcut icon" href="<?php echo e(asset($settings->media->favicon)); ?>">
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/includes/head.blade.php ENDPATH**/ ?>
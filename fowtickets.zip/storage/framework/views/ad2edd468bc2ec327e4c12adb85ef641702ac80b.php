<?php $__env->startSection('title', translate('Sign In', 'auth')); ?>
<?php $__env->startSection('content'); ?>
    <div class="sign">
        <div class="card-v">
            <div class="sign-header mb-4">
                <h4><?php echo e(translate('Sign In', 'auth')); ?></h4>
                <p class="text-muted mb-0"><?php echo e(translate('Enter your account details to sign in', 'auth')); ?></p>
            </div>
            <div class="sign-body">
                <form action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e(translate('Email address', 'forms')); ?></label>
                        <input type="email" name="email" class="form-control form-control-md" value="<?php echo e(old('email')); ?>"
                            required />
                    </div>
                    <div class="mb-3">
                        <div class="mb-2">
                            <div class="row row-cols-auto justify-content-between align-items-center g-2">
                                <div class="col">
                                    <label class="form-label mb-0"><?php echo e(translate('Password', 'forms')); ?></label>
                                </div>
                                <div class="col">
                                    <a href="<?php echo e(route('password.request')); ?>" class="d-block">
                                        <?php echo e(translate('Forgot Your Password?', 'auth')); ?>

                                    </a>
                                </div>
                            </div>
                        </div>
                        <input type="password" name="password" class="form-control form-control-md" required />
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="remember"><?php echo e(translate('Remember Me', 'auth')); ?></label>
                        </div>
                    </div>
                    <?php if (isset($component)) { $__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243 = $component; } ?>
<?php $component = App\View\Components\Captcha::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('captcha'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Captcha::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243)): ?>
<?php $component = $__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243; ?>
<?php unset($__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243); ?>
<?php endif; ?>
                    <button class="btn btn-primary btn-md w-100"><?php echo e(translate('Sign In', 'auth')); ?></button>
                </form>
                <?php if (isset($component)) { $__componentOriginalbb7bf9ecf853aa7e7b0b95ab383e2054220e3ec6 = $component; } ?>
<?php $component = App\View\Components\OauthButtons::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('oauth-buttons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\OauthButtons::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb7bf9ecf853aa7e7b0b95ab383e2054220e3ec6)): ?>
<?php $component = $__componentOriginalbb7bf9ecf853aa7e7b0b95ab383e2054220e3ec6; ?>
<?php unset($__componentOriginalbb7bf9ecf853aa7e7b0b95ab383e2054220e3ec6); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/auth/login.blade.php ENDPATH**/ ?>
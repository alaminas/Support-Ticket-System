<?php $__env->startSection('title', translate('Sign Up', 'auth')); ?>
<?php $__env->startSection('content'); ?>
    <div class="sign">
        <div class="card-v">
            <div class="sign-header mb-4">
                <h4><?php echo e(translate('Sign Up', 'auth')); ?></h4>
                <p class="text-muted mb-0"><?php echo e(translate('Enter your details to create an account.', 'auth')); ?></p>
            </div>
            <form action="<?php echo e(route('register')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(translate('Email address', 'forms')); ?></label>
                    <input type="email" name="email" class="form-control form-control-md" value="<?php echo e(old('email')); ?>"
                        required />
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(translate('Password', 'forms')); ?></label>
                    <input type="password" name="password" class="form-control form-control-md" minlength="8" required>
                </div>
                <div class="mb-3">
                    <label class="form-label"><?php echo e(translate('Confirm password', 'forms')); ?></label>
                    <input type="password" name="password_confirmation" class="form-control form-control-md" minlength="8"
                        required>
                </div>
                <?php if($settings->general->terms_link): ?>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="terms" id="terms"
                                <?php echo e(old('terms') ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="terms">
                                <?php echo e(translate('I agree to the', 'auth')); ?>

                                <a
                                    href="<?php echo e($settings->general->terms_link); ?>"><?php echo e(translate('Terms of service', 'auth')); ?></a>
                            </label>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243 = $component; } ?>
<?php $component = App\View\Components\Captcha::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('captcha'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Captcha::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243)): ?>
<?php $component = $__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243; ?>
<?php unset($__componentOriginalc0af13564821b3ac3d38dfa77d6cac9157db8243); ?>
<?php endif; ?>
                <button class="btn btn-primary btn-md w-100"><?php echo e(translate('Sign Up', 'auth')); ?></button>
            </form>
            <?php if (isset($component)) { $__componentOriginalbb7bf9ecf853aa7e7b0b95ab383e2054220e3ec6 = $component; } ?>
<?php $component = App\View\Components\OauthButtons::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('oauth-buttons'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\OauthButtons::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb7bf9ecf853aa7e7b0b95ab383e2054220e3ec6)): ?>
<?php $component = $__componentOriginalbb7bf9ecf853aa7e7b0b95ab383e2054220e3ec6; ?>
<?php unset($__componentOriginalbb7bf9ecf853aa7e7b0b95ab383e2054220e3ec6); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/auth/register.blade.php ENDPATH**/ ?>
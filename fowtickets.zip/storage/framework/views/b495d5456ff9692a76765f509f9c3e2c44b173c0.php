<?php $__env->startSection('title', admin_trans('General')); ?>
<?php $__env->startSection('section', admin_trans('Settings')); ?>
<?php $__env->startSection('content'); ?>
    <form id="vironeer-submited-form" action="<?php echo e(route('admin.settings.general.update')); ?>" method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card mb-3">
            <div class="card-header">
                <?php echo e(admin_trans('General Information')); ?>

            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Site Name')); ?> </label>
                        <input type="text" name="general[site_name]" class="form-control"
                            value="<?php echo e($settings->general->site_name); ?>" required>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Site URL')); ?> </label>
                        <input type="text" name="general[site_url]" class="form-control"
                            value="<?php echo e($settings->general->site_url); ?>" required>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Date format')); ?> </label>
                        <select name="general[date_format]" class="form-select  selectpicker" data-live-search="true"
                            title="<?php echo e(admin_trans('Date format')); ?>">
                            <?php $__currentLoopData = \App\Models\Settings::dateFormats(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formatKey => $formatValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($formatKey); ?>"
                                    <?php echo e($formatKey == $settings->general->date_format ? 'selected' : ''); ?>>
                                    <?php echo e(\Carbon\Carbon::now()->format($formatValue)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Timezone')); ?> </label>
                        <select name="general[timezone]" class="form-select selectpicker" data-live-search="true"
                            title="<?php echo e(admin_trans('Timezone')); ?>">
                            <?php $__currentLoopData = \App\Models\Settings::timezones(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timezoneKey => $timezoneValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($timezoneKey); ?>"
                                    <?php echo e($timezoneKey == $settings->general->timezone ? 'selected' : ''); ?>>
                                    <?php echo e($timezoneValue); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Contact email')); ?> </label>
                        <input type="text" name="general[contact_email]" class="form-control"
                            value="<?php echo e($settings->general->contact_email); ?>">
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Terms of service link')); ?> </label>
                        <input type="text" name="general[terms_link]" class="form-control"
                            value="<?php echo e($settings->general->terms_link); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-3">
            <div class="card-header">
                <?php echo e(admin_trans('SEO Configuration')); ?>

            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label"><?php echo e(admin_trans('Home title')); ?> </label>
                    <input type="text" name="seo[title]" class="form-control"
                        placeholder="<?php echo e(admin_trans('Title must be within 70 Characters')); ?>"
                        value="<?php echo e($settings->seo->title); ?>">
                </div>
                <div class="row g-3">
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Description')); ?> </label>
                        <textarea name="seo[description]" class="form-control" rows="6"
                            placeholder="<?php echo e(admin_trans('Description must be within 150 Characters')); ?>"><?php echo e($settings->seo->description); ?></textarea>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Site keywords')); ?> </label>
                        <textarea id="keywords" name="seo[keywords]" class="form-control" rows="6"
                            placeholder="<?php echo e(admin_trans('keyword1, keyword2, keyword3')); ?>"><?php echo e($settings->seo->keywords); ?></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-3">
            <div class="card-header">
                <?php echo e(admin_trans('Tickets')); ?>

            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-lg-12">
                        <label class="form-label"><?php echo e(admin_trans('Allowed file types')); ?></label>
                        <input type="text" name="tickets[file_types]" class="tagsInput form-control"
                            placeholder="<?php echo e(admin_trans('Enter the file extension')); ?>"
                            value="<?php echo e($settings->tickets->file_types); ?>" required>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Max upload files')); ?></label>
                        <input type="number" name="tickets[max_files]" class="form-control" placeholder="0"
                            value="<?php echo e($settings->tickets->max_files); ?>" min="1" max="1000" required>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Max size per file')); ?></label>
                        <div class="input-group">
                            <input type="number" name="tickets[max_file_size]" class="form-control" placeholder="0"
                                value="<?php echo e($settings->tickets->max_file_size); ?>" min="1" required>
                            <span class="input-group-text"><strong><?php echo e(admin_trans('MB')); ?></strong></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-3">
            <div class="card-header">
                <?php echo e(admin_trans('Colors')); ?>

            </div>
            <div class="card-body">
                <div class="row g-3">
                    <?php $__currentLoopData = $settings->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6">
                            <label class="form-label"><?php echo e(ucfirst(str($key)->replace('_', ' '))); ?> </label>
                            <div class="colorpicker">
                                <input type="text" name="colors[<?php echo e($key); ?>]" class="form-control coloris"
                                    value="<?php echo e($value); ?>" required>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="card mb-3">
            <div class="card-header">
                <?php echo e(admin_trans('Actions')); ?>

            </div>
            <div class="card-body">
                <div class="row g-3 mb-2">
                    <div class="col-xl-4">
                        <label class="form-label"><?php echo e(admin_trans('Email Verification')); ?> </label>
                        <input type="checkbox" name="actions[email_verification_status]" data-toggle="toggle"
                            <?php echo e($settings->actions->email_verification_status ? 'checked' : ''); ?>>
                    </div>
                    <div class="col-xl-4">
                        <label class="form-label"><?php echo e(admin_trans('Registration')); ?> </label>
                        <input type="checkbox" name="actions[registration_status]" data-toggle="toggle"
                            <?php echo e($settings->actions->registration_status ? 'checked' : ''); ?>>
                    </div>
                    <div class="col-xl-4">
                        <label class="form-label"><?php echo e(admin_trans('Home Page')); ?> </label>
                        <input type="checkbox" name="actions[home_page_status]" data-toggle="toggle"
                            <?php echo e($settings->actions->home_page_status ? 'checked' : ''); ?>>
                    </div>
                    <div class="col-xl-4">
                        <label class="form-label"><?php echo e(admin_trans('Knowledge Base')); ?> </label>
                        <input type="checkbox" name="actions[knowledgebase_status]" data-toggle="toggle"
                            <?php echo e($settings->actions->knowledgebase_status ? 'checked' : ''); ?>>
                    </div>
                    <div class="col-xl-4">
                        <label class="form-label"><?php echo e(admin_trans('Force SSL')); ?> </label>
                        <input type="checkbox" name="actions[force_ssl_status]" data-toggle="toggle"
                            <?php echo e($settings->actions->force_ssl_status ? 'checked' : ''); ?>>
                    </div>
                    <div class="col-xl-4">
                        <label class="form-label"><?php echo e(admin_trans('GDPR Cookie')); ?> </label>
                        <input type="checkbox" name="actions[gdpr_cookie_status]" data-toggle="toggle"
                            <?php echo e($settings->actions->gdpr_cookie_status ? 'checked' : ''); ?>>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-3">
            <div class="card-header">
                <?php echo e(admin_trans('Logo & Favicon')); ?>

            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="my-3">
                            <div class="vironeer-image-preview bg-light">
                                <img id="vironeer-preview-img-1" src="<?php echo e(asset($settings->media->logo_dark)); ?>">
                            </div>
                        </div>
                        <div class="mb-3">
                            <input id="vironeer-image-targeted-input-1" type="file" name="media[logo_dark]"
                                accept=".jpg, .jpeg, .png, .svg" class="form-control" hidden>
                            <button data-id="1" type="button"
                                class="vironeer-select-image-button btn btn-secondary btn-lg w-100 mb-2"><i
                                    class="fas fa-camera me-2"></i><?php echo e(admin_trans('Choose Dark Logo')); ?></button>
                            <small class="text-muted"><?php echo e(admin_trans('Supported (PNG, JPG, JPEG, SVG)')); ?></small>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="my-3">
                            <div class="vironeer-image-preview bg-dark">
                                <img id="vironeer-preview-img-2" src="<?php echo e(asset($settings->media->logo_light)); ?>">
                            </div>
                        </div>
                        <div class="mb-3">
                            <input id="vironeer-image-targeted-input-2" type="file" name="media[logo_light]"
                                accept=".jpg, .jpeg, .png, .svg" class="form-control" hidden>
                            <button data-id="2" type="button"
                                class="vironeer-select-image-button btn btn-secondary btn-lg w-100 mb-2"><i
                                    class="fas fa-camera me-2"></i><?php echo e(admin_trans('Choose Light Logo')); ?></button>
                            <small class="text-muted"><?php echo e(admin_trans('Supported (PNG, JPG, JPEG, SVG)')); ?></small>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="my-3">
                            <div class="vironeer-image-preview bg-light">
                                <img id="vironeer-preview-img-3" src="<?php echo e(asset($settings->media->favicon)); ?>">
                            </div>
                        </div>
                        <div class="mb-3">
                            <input id="vironeer-image-targeted-input-3" type="file" name="media[favicon]"
                                accept=".jpg, .jpeg, .png, .ico" class="form-control" hidden>
                            <button data-id="3" type="button"
                                class="vironeer-select-image-button btn btn-secondary btn-lg w-100 mb-2"><i
                                    class="fas fa-camera me-2"></i><?php echo e(admin_trans('Choose Favicon')); ?></button>
                            <small class="text-muted"><?php echo e(admin_trans('Supported (PNG, JPG, JPEG, ICO)')); ?></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(admin_trans('Social Image')); ?> <small
                            class="text-muted"><?php echo e(admin_trans('(og:image)')); ?></small>
                    </div>
                    <div class="card-body">
                        <div class="form-group mb-3">
                            <div class="vironeer-image-preview-box bg-light">
                                <img id="vironeer-preview-img-4" src="<?php echo e(asset($settings->media->social_image)); ?>"
                                    width="100%" height="315px">
                            </div>
                        </div>
                        <div class="mb-3">
                            <input id="vironeer-image-targeted-input-4" type="file" name="media[social_image]"
                                accept="image/jpg, image/jpeg" class="form-control" hidden>
                            <button data-id="4" type="button"
                                class="vironeer-select-image-button btn btn-secondary btn-lg w-100 mb-2"><i
                                    class="fas fa-camera me-2"></i><?php echo e(admin_trans('Choose Social Image')); ?></button>
                            <small class="text-muted">
                                <?php echo e(admin_trans('Supported (JPEG, JPG) Size')); ?> <strong>600x315px.</strong>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(admin_trans('Header pattern')); ?>

                    </div>
                    <div class="card-body">
                        <div class="form-group mb-3">
                            <div class="vironeer-image-preview-box bg-primary">
                                <img id="vironeer-preview-img-5" src="<?php echo e(asset($settings->media->header_pattern)); ?>"
                                    width="100%" height="315px">
                            </div>
                        </div>
                        <div class="mb-3">
                            <input id="vironeer-image-targeted-input-5" type="file" name="media[header_pattern]"
                                accept=".svg" class="form-control" hidden>
                            <button data-id="5" type="button"
                                class="vironeer-select-image-button btn btn-secondary btn-lg w-100 mb-2"><i
                                    class="fas fa-camera me-2"></i><?php echo e(admin_trans('Choose Pattern')); ?></button>
                            <small class="text-muted">
                                <?php echo e(admin_trans('Supported (SVG)')); ?>

                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <?php $__env->startPush('styles_libs'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/coloris/coloris.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/tags-input/bootstrap-tagsinput.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts_libs'); ?>
        <script src="<?php echo e(asset('assets/vendor/libs/coloris/coloris.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/libs/tags-input/bootstrap-tagsinput.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(function() {
                let tagsInput = $('.tagsInput');
                tagsInput.tagsinput({
                    cancelConfirmKeysOnEmpty: false
                });
                tagsInput.on('beforeItemAdd', function(event) {
                    if (!/^[a-zA-Z-0-9_,]+$/.test(event.item)) {
                        event.cancel = true;
                        toastr.error(
                            "<?php echo e(admin_trans('Only letters, numbers, dashes and underscores are allowed.')); ?>"
                        );
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/settings/general.blade.php ENDPATH**/ ?>
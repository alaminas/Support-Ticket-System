<!DOCTYPE html>
<html lang="<?php echo e(getLocale()); ?>" dir="<?php echo e(getDirection()); ?>">

<head>
    <?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="vironeer-page-content">
        <?php echo $__env->make('admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container <?php echo $__env->yieldContent('container'); ?>">
            <div class="vironeer-page-body px-1 px-sm-2 px-xxl-0">
                <div class="py-4 g-4">
                    <div class="row align-items-center">
                        <div class="col">
                            <?php echo $__env->make('admin.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-auto">
                            <?php if (! empty(trim($__env->yieldContent('back')))): ?>
                                <a href="<?php echo $__env->yieldContent('back'); ?>" class="btn btn-secondary ms-2"><i
                                        class="fas fa-arrow-left fa-rtl me-2"></i><?php echo e(admin_trans('Back')); ?></a>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('modal')))): ?>
                                <button type="button" class="btn btn-dark ms-2" data-bs-toggle="modal"
                                    data-bs-target="#viewModal">
                                    <?php echo $__env->yieldContent('modal'); ?>
                                </button>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('link')))): ?>
                                <a href="<?php echo $__env->yieldContent('link'); ?>" class="btn btn-primary ms-2"><i class="fa fa-plus"></i></a>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('add_modal')))): ?>
                                <button type="button" class="btn btn-primary ms-2" data-bs-toggle="modal"
                                    data-bs-target="#addModal">
                                    <i class="fa fa-plus"></i>
                                </button>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('upload_modal')))): ?>
                                <button type="button" class="btn btn-primary ms-2" data-bs-toggle="modal"
                                    data-bs-target="#addModal">
                                    <i class="fa fa-upload me-2"></i><?php echo $__env->yieldContent('upload_modal'); ?>
                                </button>
                            <?php endif; ?>
                            <?php if(request()->routeIs('admin.notifications.index')): ?>
                                <a class="action-confirm btn btn-outline-success ms-2"
                                    href="<?php echo e(route('admin.notifications.read.all')); ?>">
                                    <i class="fa-regular fa-bookmark me-1"></i>
                                    <?php echo e(admin_trans('Make All as Read')); ?>

                                </a>
                                <form class="d-inline ms-2" action="<?php echo e(route('admin.notifications.destroy.all')); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="action-confirm btn btn-outline-danger">
                                        <i class="fa-regular fa-trash-can me-1"></i>
                                        <?php echo e(admin_trans('Delete All Read')); ?>

                                    </button>
                                </form>
                            <?php endif; ?>
                            <?php if(request()->routeIs('admin.system.info.index')): ?>
                                <a href="<?php echo e(config('system.author.profile')); ?>" target="_blank"
                                    class="btn btn-secondary"><i
                                        class="far fa-question-circle me-2"></i><?php echo e(admin_trans('Get Help')); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row g-3 g-xl-3">
                    <div class="col">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('admin.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/layouts/grid.blade.php ENDPATH**/ ?>
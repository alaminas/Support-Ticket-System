<?php $__env->startSection('title', admin_trans('Departments')); ?>
<?php $__env->startSection('container', 'container-max-lg'); ?>
<?php $__env->startSection('link', route('admin.departments.create')); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <table class="table datatable w-100">
            <thead>
                <tr>
                    <th class="tb-w-2x">#</th>
                    <th class="tb-w-7x"><?php echo e(admin_trans('Name')); ?></th>
                    <th class="tb-w-3x"><?php echo e(admin_trans('Status')); ?></th>
                    <th class="tb-w-7x"><?php echo e(admin_trans('Created date')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="item">
                        <td><?php echo e($department->id); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.departments.edit', $department->id)); ?>" class="text-dark">
                                <?php echo e($department->name); ?>

                            </a>
                        </td>
                        <td>
                            <?php if($department->isActive()): ?>
                                <span class="badge bg-success"><?php echo e(admin_trans('Active')); ?></span>
                            <?php else: ?>
                                <span class="badge bg-danger"><?php echo e(admin_trans('Disabled')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(dateFormat($department->created_at)); ?></td>
                        <td>
                            <div class="text-end">
                                <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown"
                                    aria-expanded="true">
                                    <i class="fa fa-ellipsis-v fa-sm text-muted"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-sm-end" data-popper-placement="bottom-end">
                                    <li>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('admin.departments.edit', $department->id)); ?>"><i
                                                class="fa fa-edit me-2"></i><?php echo e(admin_trans('Edit')); ?></a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('admin.tickets.index', 'department=' . $department->id)); ?>"><i
                                                class="fa-solid fa-inbox me-2"></i><?php echo e(admin_trans('View tickets')); ?></a>
                                    </li>
                                    <li>
                                        <hr class="dropdown-divider" />
                                    </li>
                                    <li>
                                        <form action="<?php echo e(route('admin.departments.destroy', $department->id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="action-confirm dropdown-item text-danger"><i
                                                    class="far fa-trash-alt me-2"></i><?php echo e(admin_trans('Delete')); ?></button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/departments/index.blade.php ENDPATH**/ ?>
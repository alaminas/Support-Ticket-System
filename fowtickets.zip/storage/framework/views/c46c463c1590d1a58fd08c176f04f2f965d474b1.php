<footer>
    <p class="mb-0"> &copy; <span data-year></span> <?php echo e($settings->general->site_name); ?> -
        <?php echo e(admin_trans('All rights reserved.')); ?> | <span class="capitalize"><?php echo e(config('system.item.alias')); ?></span>
        v<?php echo e(config('system.item.version')); ?></p>
    <p class="mb-0 ms-auto"><?php echo e(admin_trans('Powered by Vironeer')); ?></p>
</footer>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>
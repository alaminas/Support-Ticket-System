 <link rel="stylesheet" href="<?php echo e(asset("assets/vendor/libs/bootstrap/bootstrap.min.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/fontawesome/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/simplebar/simplebar.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/datatable/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/vironeer/counter-cards.min.css')); ?>">
<?php echo $__env->yieldPushContent('styles_libs'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/toggle-master/bootstrap-toggle.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/vironeer/toastr/css/vironeer-toastr.min.css')); ?>">
<link rel="stylesheet" href="http://127.0.0.1:8000/assets/vendor/admin/css/colors.css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/admin/css/app.css')); ?>">
<?php if(getDirection() == 'rtl'): ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/admin/css/app.rtl.css')); ?>">
<?php endif; ?>
<link rel="stylesheet" href="http://127.0.0.1:8000/assets/vendor/admin/css/custom.css">
<?php echo $__env->yieldPushContent('styles'); ?>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/includes/styles.blade.php ENDPATH**/ ?>
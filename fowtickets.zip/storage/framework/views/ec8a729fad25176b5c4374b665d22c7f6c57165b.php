<?php echo $__env->make('admin.includes.config', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('top_scripts'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/simplebar/simplebar.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts_libs'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/toggle-master/bootstrap-toggle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/datatable/datatables.jq.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/vironeer/toastr/js/vironeer-toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/admin/js/app.js')); ?>"></script>
<?php echo app('toastr')->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/includes/scripts.blade.php ENDPATH**/ ?>
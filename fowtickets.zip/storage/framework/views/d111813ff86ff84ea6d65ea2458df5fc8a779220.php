<!DOCTYPE html>
<html lang="<?php echo e(getLocale()); ?>" dir="<?php echo e(getDirection()); ?>">

<head>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if (! empty(trim($__env->yieldContent('header')))): ?>
        <header class="header">
            <div class="wrapper wrapper-page"
                style="background-image: url(<?php echo e(asset($settings->media->header_pattern)); ?>);">
                <div class="container">
                    <div class="wrapper-content">
                        <div class="wrapper-container">
                            <h1 class="page-title">
                                <?php echo $__env->yieldContent('title'); ?>
                            </h1>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.config', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/layouts/app.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', admin_trans('Footer Menu')); ?>
<?php $__env->startSection('container', 'container-max-lg'); ?>
<?php $__env->startSection('link', route('admin.footer-menu.create')); ?>
<?php if($footerMenuLinks->count() == 0): ?>
    <?php $__env->startSection('btn_action', 'disabled'); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
    <?php if($footerMenuLinks->count() > 0): ?>
        <form id="vironeer-submited-form" action="<?php echo e(route('admin.footer-menu.sort')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input name="ids" id="ids" hidden>
        </form>
        <div class="card mb-3">
            <ul class="vironeer-sort-menu custom-list-group list-group list-group-flush">
                <?php $__currentLoopData = $footerMenuLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footerMenuLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center"
                        data-id="<?php echo e($footerMenuLink->id); ?>">
                        <div class="item-title">
                            <span class="vironeer-navigation-handle me-2 text-muted"><i
                                    class="fas fa-arrows-alt"></i></span>
                            <span><?php echo e($footerMenuLink->name); ?></span>
                        </div>
                        <div class="buttons">
                            <a href="<?php echo e(route('admin.footer-menu.edit', $footerMenuLink->id)); ?>"
                                class="vironeer-edit-footer-menu btn btn-blue btn-sm me-2"><i class="fa fa-edit"></i></a>
                            <form class="d-inline" action="<?php echo e(route('admin.footer-menu.destroy', $footerMenuLink->id)); ?>"
                                method="POST">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="action-confirm btn btn-danger btn-sm"><i
                                        class="far fa-trash-alt"></i></button>
                            </form>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('admin.partials.empty', ['size' => 180], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    <?php endif; ?>
    <?php if($footerMenuLinks->count() > 0): ?>
        <?php $__env->startPush('styles_libs'); ?>
            <link href="<?php echo e(asset('assets/vendor/libs/jquery/jquery-ui.min.css')); ?>" />
        <?php $__env->stopPush(); ?>
        <?php $__env->startPush('scripts_libs'); ?>
            <script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery-ui.min.js')); ?>"></script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/navigation/footer-menu/index.blade.php ENDPATH**/ ?>
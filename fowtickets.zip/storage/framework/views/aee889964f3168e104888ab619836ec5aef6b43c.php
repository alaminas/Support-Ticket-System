<?php $__env->startSection('title', admin_trans('Navbar Menu')); ?>
<?php $__env->startSection('container', 'container-max-lg'); ?>
<?php $__env->startSection('link', route('admin.navbar-menu.create')); ?>
<?php if($navbarMenuLinks->count() == 0): ?>
    <?php $__env->startSection('btn_action', 'disabled'); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
    <?php if($navbarMenuLinks->count() > 0): ?>
        <form id="vironeer-submited-form" action="<?php echo e(route('admin.navbar-menu.nestable')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input name="ids" id="ids" hidden>
        </form>
        <div class="card border-0">
            <div class="dd nestable">
                <ol class="dd-list">
                    <?php $__currentLoopData = $navbarMenuLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navbarMenuLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="dd-item" data-id="<?php echo e($navbarMenuLink->id); ?>">
                            <div class="dd-handle">
                                <span class="drag-indicator"></span>
                                <span class="dd-title"><?php echo e($navbarMenuLink->name); ?></span>
                                <div class="dd-nodrag ms-auto">
                                    <a href="<?php echo e(route('admin.navbar-menu.edit', $navbarMenuLink->id)); ?>"
                                        class="btn btn-sm btn-blue me-2"><i class="fa fa-edit"></i></a>
                                    <form class="d-inline"
                                        action="<?php echo e(route('admin.navbar-menu.destroy', $navbarMenuLink->id)); ?>"
                                        method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="action-confirm btn btn-sm btn-danger"><i
                                                class="far fa-trash-alt"></i></button>
                                    </form>
                                </div>
                            </div>
                            <?php if(count($navbarMenuLink->children)): ?>
                                <ol class="dd-list">
                                    <?php $__currentLoopData = $navbarMenuLink->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="dd-item" data-id="<?php echo e($child->id); ?>">
                                            <div class="dd-handle">
                                                <span class="drag-indicator"></span>
                                                <span class="dd-title"><?php echo e($child->name); ?></span>
                                                <div class="dd-nodrag ms-auto">
                                                    <a href="<?php echo e(route('admin.navbar-menu.edit', $child->id)); ?>"
                                                        class="btn btn-sm btn-blue me-2"><i class="fa fa-edit"></i></a>
                                                    <form class="d-inline"
                                                        action="<?php echo e(route('admin.navbar-menu.destroy', $child->id)); ?>"
                                                        method="POST">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button class="action-confirm btn btn-sm btn-danger"><i
                                                                class="far fa-trash-alt"></i></button>
                                                    </form>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('admin.partials.empty', ['size' => 180], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    <?php endif; ?>
    <?php if($navbarMenuLinks->count() > 0): ?>
        <?php $__env->startPush('styles_libs'); ?>
            <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/jquery/nestable/jquery.nestable.min.css')); ?>">
        <?php $__env->stopPush(); ?>
        <?php $__env->startPush('scripts_libs'); ?>
            <script src="<?php echo e(asset('assets/vendor/libs/jquery/nestable/jquery.nestable.min.js')); ?>"></script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/navigation/navbar-menu/index.blade.php ENDPATH**/ ?>
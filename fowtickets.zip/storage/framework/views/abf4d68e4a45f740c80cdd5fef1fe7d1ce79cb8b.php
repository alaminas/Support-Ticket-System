<?php $__env->startSection('title', admin_trans('Tickets')); ?>
<?php $__env->startSection('link', route('admin.tickets.create')); ?>
<?php $__env->startSection('content'); ?>
    <div class="row g-3 mb-4">
        <div class="col-12 col-lg-6 col-xxl-6">
            <div class="vironeer-counter-card bg-primary">
                <div class="vironeer-counter-card-icon">
                    <i class="fa-regular fa-clock"></i>
                </div>
                <div class="vironeer-counter-card-meta">
                    <p class="vironeer-counter-card-title"><?php echo e(admin_trans('Opened tickets')); ?></p>
                    <p class="vironeer-counter-card-number"><?php echo e($counters['opened_tickets']); ?></p>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xxl-6">
            <div class="vironeer-counter-card bg-danger">
                <div class="vironeer-counter-card-icon">
                    <i class="fa-regular fa-circle-xmark"></i>
                </div>
                <div class="vironeer-counter-card-meta">
                    <p class="vironeer-counter-card-title"><?php echo e(admin_trans('Closed tickets')); ?></p>
                    <p class="vironeer-counter-card-number"><?php echo e($counters['closed_tickets']); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="custom-card card">
        <div class="card-header p-3 border-bottom-small">
            <form action="<?php echo e(request()->url()); ?>" method="GET">
                <div class="row g-3">
                    <div class="col-12">
                        <input type="text" name="search" class="form-control"
                            placeholder="<?php echo e(admin_trans('Search...')); ?>" value="<?php echo e(request()->input('search') ?? ''); ?>">
                    </div>
                    <div class="col-12 col-lg-3">
                        <select name="user" class="form-select selectpicker" title="<?php echo e(admin_trans('User')); ?>"
                            data-live-search="true">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == request('user') ? 'selected' : ''); ?>>
                                    <?php echo e($user->getName()); ?> (<?php echo e($user->email); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-lg-3">
                        <select name="department" class="form-select selectpicker" title="<?php echo e(admin_trans('Department')); ?>"
                            data-live-search="true">
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>"
                                    <?php echo e($department->id == request('department') ? 'selected' : ''); ?>>
                                    <?php echo e($department->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-lg-2">
                        <select name="priority" class="form-select selectpicker" title="<?php echo e(admin_trans('Priority')); ?>">
                            <?php $__currentLoopData = \App\Models\Ticket::getPriorityOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($key == request('priority') ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-lg-2">
                        <select name="status" class="form-select selectpicker" title="<?php echo e(admin_trans('Status')); ?>">
                            <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>
                                <?php echo e(admin_trans('Opened')); ?>

                            </option>
                            <option value="2" <?php echo e(request('status') == '2' ? 'selected' : ''); ?>>
                                <?php echo e(admin_trans('Closed')); ?></option>
                        </select>
                    </div>
                    <div class="col">
                        <button class="btn btn-primary w-100"><i class="fa fa-search"></i></button>
                    </div>
                    <div class="col">
                        <a href="<?php echo e(route('admin.tickets.index')); ?>"
                            class="btn btn-secondary w-100"><?php echo e(admin_trans('Reset')); ?></a>
                    </div>
                </div>
            </form>
        </div>
        <div>
            <?php if($tickets->count() > 0): ?>
                <div class="table-responsive">
                    <table class="vironeer-normal-table table w-100">
                        <thead>
                            <tr>
                                <th><?php echo e(admin_trans('ID')); ?></th>
                                <th><?php echo e(admin_trans('Subject')); ?></th>
                                <th><?php echo e(admin_trans('User')); ?></th>
                                <th><?php echo e(admin_trans('Department')); ?></th>
                                <th><?php echo e(admin_trans('Priority')); ?></th>
                                <th class="text-center"><?php echo e(admin_trans('Status')); ?></th>
                                <th class="text-center"><?php echo e(admin_trans('Created date')); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('admin.tickets.show', $ticket->id)); ?>"><i
                                                class="fa-solid fa-ticket me-1"></i>#<?php echo e($ticket->id); ?></a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.tickets.show', $ticket->id)); ?>" class="text-dark">
                                            <?php echo e(shorterText($ticket->subject, 50)); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.members.users.edit', $ticket->user->id)); ?>"
                                            class="text-dark">
                                            <i class="fa fa-user me-1"></i>
                                            <?php echo e($ticket->user->getName()); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.departments.edit', $ticket->department->id)); ?>"
                                            class="text-dark">
                                            <?php echo e($ticket->department->name); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <?php echo e($ticket->getPriority()); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php if($ticket->isOpened()): ?>
                                            <span class="badge bg-primary"><?php echo e(admin_trans('Opened')); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><?php echo e(admin_trans('Closed')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center"><?php echo e(dateFormat($ticket->created_at)); ?></td>
                                    <td>
                                        <div class="text-end">
                                            <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown"
                                                aria-expanded="true">
                                                <i class="fa fa-ellipsis-v fa-sm text-muted"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-sm-end"
                                                data-popper-placement="bottom-end">
                                                <li>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('admin.tickets.show', $ticket->id)); ?>"><i
                                                            class="fas fa-eye me-2"></i><?php echo e(admin_trans('View')); ?></a>
                                                </li>
                                                <li>
                                                    <hr class="dropdown-divider" />
                                                </li>
                                                <li>
                                                    <form action="<?php echo e(route('admin.tickets.destroy', $ticket->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                        <button class="action-confirm dropdown-item text-danger"><i
                                                                class="far fa-trash-alt me-2"></i><?php echo e(admin_trans('Delete')); ?></button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <?php echo $__env->make('admin.partials.empty', ['size' => 180], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
    <?php echo e($tickets->links()); ?>

    <?php $__env->startPush('styles_libs'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts_libs'); ?>
        <script src="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/tickets/index.blade.php ENDPATH**/ ?>
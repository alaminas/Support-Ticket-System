<?php $__env->startSection('section', admin_trans('Members')); ?>
<?php $__env->startSection('title', admin_trans('New User')); ?>
<?php $__env->startSection('back', route('admin.members.users.index')); ?>
<?php $__env->startSection('container', 'container-max-lg'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <?php echo e(admin_trans('User details')); ?>

        </div>
        <div class="card-body p-4">
            <form id="vironeer-submited-form" action="<?php echo e(route('admin.members.users.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row g-3 mb-2">
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('First Name')); ?> </label>
                        <input type="firstname" name="firstname" class="form-control form-control-lg"
                            value="<?php echo e(old('firstname')); ?>" required>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Last Name')); ?> </label>
                        <input type="lastname" name="lastname" class="form-control form-control-lg"
                            value="<?php echo e(old('lastname')); ?>" required>
                    </div>
                    <div class="col-lg-12">
                        <label class="form-label"><?php echo e(admin_trans('E-mail Address')); ?> </label>
                        <input type="email" name="email" class="form-control form-control-lg"
                            value="<?php echo e(old('email')); ?>" required>
                    </div>
                    <div class="col-lg-12">
                        <label class="form-label"><?php echo e(admin_trans('Password')); ?> </label>
                        <div class="input-group">
                            <input id="randomPasswordInput" type="text" class="form-control form-control-lg"
                                name="password" required>
                            <button id="copy-btn" class="btn btn-secondary" type="button"
                                data-clipboard-target="#randomPasswordInput"><i class="far fa-clone"></i></button>
                            <button id="randomPasswordBtn" class="btn btn-secondary" type="button"><i
                                    class="fa-solid fa-rotate me-2"></i><?php echo e(admin_trans('Generate')); ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php $__env->startPush('scripts_libs'); ?>
        <script src="<?php echo e(asset('assets/vendor/libs/clipboard/clipboard.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/members/users/create.blade.php ENDPATH**/ ?>
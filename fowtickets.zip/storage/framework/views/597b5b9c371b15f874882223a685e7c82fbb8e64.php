<?php $__env->startSection('section', admin_trans('Knowledge base')); ?>
<?php $__env->startSection('title', admin_trans('Articles')); ?>
<?php $__env->startSection('link', route('admin.knowledgebase.articles.create')); ?>
<?php $__env->startSection('content'); ?>
    <div class="custom-card card">
        <div class="card-header p-3 border-bottom-small">
            <form class="multiple-select-search-form" class="multiple-select-search-form" action="<?php echo e(request()->url()); ?>"
                method="GET">
                <div class="row g-3">
                    <div class="col-12 col-lg-8">
                        <input type="text" name="search" class="form-control" placeholder="<?php echo e(admin_trans('Search...')); ?>"
                            value="<?php echo e(request()->input('search') ?? ''); ?>">
                    </div>
                    <div class="col-12 col-lg-2">
                        <select name="category" class="form-select selectpicker" title="<?php echo e(admin_trans('Category')); ?>">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col">
                        <button class="btn btn-primary w-100"><i class="fa fa-search"></i></button>
                    </div>
                    <div class="col">
                        <a href="<?php echo e(route('admin.knowledgebase.articles.index')); ?>"
                            class="btn btn-secondary w-100"><?php echo e(admin_trans('Reset')); ?></a>
                    </div>
                </div>
            </form>
            <form class="multiple-select-delete-form d-none"
                action="<?php echo e(route('admin.knowledgebase.articles.destroy.selected')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" name="delete_ids" class="multiple-select-delete-ids" hidden>
                <button class="action-confirm btn btn-danger"><i
                        class="far fa-trash-alt me-2"></i><?php echo e(admin_trans('Delete Selected')); ?></button>
            </form>
        </div>
        <div>
            <?php if($articles->count() > 0): ?>
                <div class="table-responsive">
                    <table class="vironeer-normal-table table w-100">
                        <thead>
                            <tr>
                                <th class="tb-w-3x">
                                    <input class="multiple-select-check-all form-check-input" type="checkbox">
                                </th>
                                <th><?php echo e(admin_trans('ID')); ?></th>
                                <th><?php echo e(admin_trans('Article')); ?></th>
                                <th><?php echo e(admin_trans('Categories')); ?></th>
                                <th><?php echo e(admin_trans('Views')); ?></th>
                                <th><?php echo e(admin_trans('Likes')); ?></th>
                                <th><?php echo e(admin_trans('Dislikes')); ?></th>
                                <th><?php echo e(admin_trans('Published date')); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <input class="form-check-input multiple-select-checkbox"
                                            data-id="<?php echo e($article->id); ?>" type="checkbox">
                                    </td>
                                    <td><?php echo e($article->id); ?></td>
                                    <td>
                                        <div class="vironeer-content-box">
                                            <div class="vironeer-content-image">
                                                <i class="fa-regular fa-file-lines fa-3x text-muted"></i>
                                            </div>
                                            <div>
                                                <a class="text-reset"
                                                    href="<?php echo e(route('admin.knowledgebase.articles.edit', $article->id)); ?>"><?php echo e(shorterText($article->title, 30)); ?></a>
                                                <p class="text-muted mb-0">
                                                    <?php echo e(shorterText($article->short_description, 40)); ?></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($article->categories->count() > 0): ?>
                                            <div class="row g-2">
                                                <?php $__currentLoopData = $article->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-auto">
                                                        <a
                                                            href="<?php echo e(route('admin.knowledgebase.categories.edit', $category->id)); ?>">
                                                            <span class="badge bg-primary"><?php echo e($category->name); ?></span>
                                                        </a>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php else: ?>
                                            <span>--</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="badge bg-dark"><?php echo e($article->views); ?></span></td>
                                    <td><span class="badge bg-success"><?php echo e($article->likes); ?></span></td>
                                    <td><span class="badge bg-danger"><?php echo e($article->dislikes); ?></span></td>
                                    <td><?php echo e(dateFormat($article->created_at)); ?></td>
                                    <td>
                                        <div class="text-end">
                                            <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown"
                                                aria-expanded="true">
                                                <i class="fa fa-ellipsis-v fa-sm text-muted"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-sm-end"
                                                data-popper-placement="bottom-end">
                                                <li>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('knowledgebase.article', $article->slug)); ?>"
                                                        target="_blank"><i
                                                            class="fa fa-eye me-2"></i><?php echo e(admin_trans('Preview')); ?></a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('admin.knowledgebase.articles.edit', $article->id)); ?>"><i
                                                            class="fa fa-edit me-2"></i><?php echo e(admin_trans('Edit')); ?></a>
                                                </li>
                                                <li>
                                                    <hr class="dropdown-divider" />
                                                </li>
                                                <li>
                                                    <form
                                                        action="<?php echo e(route('admin.knowledgebase.articles.destroy', $article->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                        <button class="action-confirm dropdown-item text-danger"><i
                                                                class="far fa-trash-alt me-2"></i><?php echo e(admin_trans('Delete')); ?></button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <?php echo $__env->make('admin.partials.empty', ['size' => 180], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
    <?php echo e($articles->links()); ?>

    <?php $__env->startPush('styles_libs'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts_libs'); ?>
        <script src="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/knowledgebase/articles/index.blade.php ENDPATH**/ ?>
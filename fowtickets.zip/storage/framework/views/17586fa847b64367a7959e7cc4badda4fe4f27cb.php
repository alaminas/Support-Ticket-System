<?php if (isset($component)) { $__componentOriginal05050c4e2511d68951c7870663bac38a5ac720a1 = $component; } ?>
<?php $component = App\View\Components\Extensions::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('extensions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Extensions::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal05050c4e2511d68951c7870663bac38a5ac720a1)): ?>
<?php $component = $__componentOriginal05050c4e2511d68951c7870663bac38a5ac720a1; ?>
<?php unset($__componentOriginal05050c4e2511d68951c7870663bac38a5ac720a1); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal057ee741994856236e7cb66eea85cb4b6d9d26bc = $component; } ?>
<?php $component = App\View\Components\Partials::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('partials'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Partials::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal057ee741994856236e7cb66eea85cb4b6d9d26bc)): ?>
<?php $component = $__componentOriginal057ee741994856236e7cb66eea85cb4b6d9d26bc; ?>
<?php unset($__componentOriginal057ee741994856236e7cb66eea85cb4b6d9d26bc); ?>
<?php endif; ?>
<?php echo $__env->yieldPushContent('top_scripts'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/vironeer/toastr/js/vironeer-toastr.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts_libs'); ?>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<?php echo app('toastr')->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/includes/scripts.blade.php ENDPATH**/ ?>
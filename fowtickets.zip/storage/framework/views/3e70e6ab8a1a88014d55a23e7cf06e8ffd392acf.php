<?php $__env->startSection('section', admin_trans('Members')); ?>
<?php $__env->startSection('title', admin_trans('Agent') . ' | ' . $agent->getName()); ?>
<?php $__env->startSection('back', route('admin.members.agents.index')); ?>
<?php $__env->startSection('container', 'container-max-lg'); ?>
<?php $__env->startSection('content'); ?>
    <form id="vironeer-submited-form" action="<?php echo e(route('admin.members.agents.update', $agent->id)); ?>" method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="card custom-card mb-3">
            <div class="card-header"><?php echo e(admin_trans('Actions')); ?></div>
            <div class="card-body p-4">
                <div class="row g-3">
                    <div class="col-lg-4">
                        <label class="form-label"><?php echo e(admin_trans('Two-Factor Authentication')); ?> </label>
                        <input id="2faCheckbox" type="checkbox" name="google2fa_status" data-toggle="toggle"
                            data-on="<?php echo e(admin_trans('Active')); ?>" data-off="<?php echo e(admin_trans('Disabled')); ?>"
                            <?php echo e($agent->has2fa() ? 'checked' : ''); ?>>
                    </div>
                </div>
            </div>
        </div>
        <div class="card custom-card">
            <div class="card-header"><?php echo e(admin_trans('Account details')); ?></div>
            <div class="card-body p-4">
                <div class="row align-items-center mb-4">
                    <div class="col-auto">
                        <img id="filePreview" src="<?php echo e($agent->getAvatar()); ?>" alt="<?php echo e($agent->getName()); ?>"
                            class="rounded-circle border" width="80px" height="80px">
                    </div>
                    <div class="col-auto">
                        <button id="selectFileBtn" type="button" class="btn btn-secondary btn-sm"><i
                                class="fas fa-camera me-2"></i><?php echo e(admin_trans('Choose Image')); ?></button>
                        <input id="selectedFileInput" type="file" name="avatar"
                            accept="image/png, image/jpg, image/jpeg" hidden>
                    </div>
                </div>
                <div class="row g-3 mb-2">
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('First Name')); ?> </label>
                        <input type="firstname" name="firstname" class="form-control form-control-lg"
                            value="<?php echo e($agent->firstname); ?>">
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Last Name')); ?> </label>
                        <input type="lastname" name="lastname" class="form-control form-control-lg"
                            value="<?php echo e($agent->lastname); ?>">
                    </div>
                    <div class="col-lg-12">
                        <label class="form-label"><?php echo e(admin_trans('E-mail Address')); ?> </label>
                        <input type="email" name="email" class="form-control form-control-lg"
                            value="<?php echo e($agent->email); ?>" required>
                    </div>
                    <div class="col-lg-12">
                        <label class="form-label"><?php echo e(admin_trans('Departments')); ?> </label>
                        <select name="departments[]" class="form-select form-select-lg selectpicker" data-live-search="true"
                            multiple title="<?php echo e(admin_trans('Choose')); ?>">
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>"
                                    <?php echo e(in_array($department->id, $agentDepartmentIds) ? 'selected' : ''); ?>>
                                    <?php echo e($department->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <?php $__env->startPush('styles_libs'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts_libs'); ?>
        <script src="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/members/agents/edit.blade.php ENDPATH**/ ?>
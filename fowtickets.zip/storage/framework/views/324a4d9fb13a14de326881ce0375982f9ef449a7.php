<?php $__env->startSection('section', admin_trans('Members')); ?>
<?php $__env->startSection('title', admin_trans('User') . ' | ' . $user->getName()); ?>
<?php $__env->startSection('back', route('admin.members.users.index')); ?>
<?php $__env->startSection('container', 'container-max-lg'); ?>
<?php $__env->startSection('content'); ?>
    <form id="vironeer-submited-form" action="<?php echo e(route('admin.members.users.update', $user->id)); ?>" method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="card custom-card mb-3">
            <div class="card-header"><?php echo e(admin_trans('Actions')); ?></div>
            <div class="card-body p-4">
                <div class="row g-3">
                    <div class="col-lg-4">
                        <label class="form-label"><?php echo e(admin_trans('Account status')); ?> </label>
                        <input type="checkbox" name="status" data-toggle="toggle" data-on="<?php echo e(admin_trans('Active')); ?>"
                            data-off="<?php echo e(admin_trans('Banned')); ?>" <?php echo e($user->isActive() ? 'checked' : ''); ?>>
                    </div>
                    <div class="col-lg-4">
                        <label class="form-label"><?php echo e(admin_trans('Email status')); ?> </label>
                        <input type="checkbox" name="email_status" data-toggle="toggle"
                            data-on="<?php echo e(admin_trans('Verified')); ?>" data-off="<?php echo e(admin_trans('Unverified')); ?>"
                            <?php echo e($user->isVerified() ? 'checked' : ''); ?>>
                    </div>
                    <div class="col-lg-4">
                        <label class="form-label"><?php echo e(admin_trans('Two-Factor Authentication')); ?> </label>
                        <input id="2faCheckbox" type="checkbox" name="google2fa_status" data-toggle="toggle"
                            data-on="<?php echo e(admin_trans('Active')); ?>" data-off="<?php echo e(admin_trans('Disabled')); ?>"
                            <?php echo e($user->has2fa() ? 'checked' : ''); ?>>
                    </div>
                </div>
            </div>
        </div>
        <div class="card custom-card">
            <div class="card-header"><?php echo e(admin_trans('Account details')); ?></div>
            <div class="card-body p-4">
                <div class="row align-items-center mb-4">
                    <div class="col-auto">
                        <img id="filePreview" src="<?php echo e($user->getAvatar()); ?>" alt="<?php echo e($user->getName()); ?>"
                            class="rounded-circle border" width="80px" height="80px">
                    </div>
                    <div class="col-auto">
                        <button id="selectFileBtn" type="button" class="btn btn-secondary btn-sm"><i
                                class="fas fa-camera me-2"></i><?php echo e(admin_trans('Choose Image')); ?></button>
                        <input id="selectedFileInput" type="file" name="avatar"
                            accept="image/png, image/jpg, image/jpeg" hidden>
                    </div>
                </div>
                <div class="row g-3 mb-2">
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('First Name')); ?> </label>
                        <input type="firstname" name="firstname" class="form-control form-control-lg"
                            value="<?php echo e($user->firstname); ?>">
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label"><?php echo e(admin_trans('Last Name')); ?> </label>
                        <input type="lastname" name="lastname" class="form-control form-control-lg"
                            value="<?php echo e($user->lastname); ?>">
                    </div>
                    <div class="col-lg-12">
                        <label class="form-label"><?php echo e(admin_trans('E-mail Address')); ?> </label>
                        <div class="input-group">
                            <input type="email" name="email" class="form-control form-control-lg"
                                value="<?php echo e($user->email); ?>" required>
                            <button class="btn btn-dark" type="button" data-bs-toggle="modal"
                                data-bs-target="#sendMailModal"><i
                                    class="far fa-paper-plane me-2"></i><?php echo e(admin_trans('Send Email')); ?></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <div class="modal fade" id="sendMailModal" tabindex="-1" aria-labelledby="sendMailModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="sendMailModalLabel"><?php echo e(admin_trans('Send Mail to ')); ?><?php echo e($user->email); ?>

                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('admin.members.users.sendmail', $user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(admin_trans('Subject')); ?> </label>
                                    <input type="subject" name="subject" class="form-control form-control-lg" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e(admin_trans('Reply to')); ?> </label>
                                    <input type="email" name="reply_to" class="form-control form-control-lg"
                                        value="<?php echo e(auth()->user()->email); ?>" required>
                                </div>
                            </div>
                        </div>
                        <textarea name="message" rows="10" class="ckeditor"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary btn-lg"><?php echo e(admin_trans('Send')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.includes.ckeditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/members/users/edit.blade.php ENDPATH**/ ?>
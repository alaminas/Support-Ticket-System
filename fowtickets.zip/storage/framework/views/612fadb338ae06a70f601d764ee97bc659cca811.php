<header class="vironeer-page-header">
    <div class="vironeer-sibebar-icon me-auto">
        <i class="fa fa-bars fa-lg"></i>
    </div>
    <div class="row row-cols-auto g-3">
        <div class="col">
            <a href="<?php echo e(route('admin.system.info.cache')); ?>" class="btn btn-outline-danger rounded-3 action-confirm">
                <i class="fa-solid fa-broom"></i>
                <span class="d-none d-lg-inline ms-1"><?php echo e(admin_trans('Clear Cache')); ?></span>
            </a>
        </div>
        <div class="col">
            <a href="<?php echo e(url('/')); ?>" target="_blank" class="btn btn-outline-dark rounded-3">
                <i class="fa-solid fa-eye"></i>
                <span class="d-none d-lg-inline ms-1"><?php echo e(admin_trans('Preview')); ?></span>
            </a>
        </div>
    </div>
    <div class="vironeer-notifications ms-2" data-dropdown-v2>
        <div class="vironeer-notifications-title">
            <i class="far fa-bell"></i>
            <?php if($notifications['unread']): ?>
                <div class="counter"><?php echo e($notifications['unread'] > 9 ? '9+' : $notifications['unread']); ?></div>
            <?php endif; ?>
        </div>
        <div class="vironeer-notifications-menu">
            <div class="vironeer-notifications-header">
                <p class="vironeer-notifications-header-title mb-0">
                    <?php echo e(admin_trans('Notifications')); ?> (<?php echo e($notifications['unread']); ?>)</p>
                <?php if($notifications['unread'] > 0): ?>
                    <a href="<?php echo e(route('admin.notifications.read.all')); ?>"
                        class="ms-auto action-confirm"><?php echo e(admin_trans('Mark All as Read')); ?></a>
                <?php else: ?>
                    <span class="ms-auto text-muted"><?php echo e(admin_trans('Mark All as Read')); ?></span>
                <?php endif; ?>
            </div>
            <div class="vironeer-notifications-body">
                <?php $__empty_1 = true; $__currentLoopData = $notifications['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($notification->link): ?>
                        <a class="vironeer-notification"
                            href="<?php echo e(route('admin.notifications.view', $notification->id)); ?>">
                            <div class="vironeer-notification-image">
                                <img src="<?php echo e($notification->image); ?>" alt="<?php echo e($notification->title); ?>">
                            </div>
                            <div class="vironeer-notification-info">
                                <p
                                    class="vironeer-notification-title mb-0 d-flex justify-content-between align-items-center">
                                    <span><?php echo e(shorterText($notification->title, 30)); ?></span>
                                    <?php if(!$notification->status): ?>
                                        <span class="unread flashit"><i class="fas fa-circle"></i></span>
                                    <?php endif; ?>
                                </p>
                                <p class="vironeer-notification-text mb-0">
                                    <?php echo e($notification->created_at->diffforhumans()); ?>

                                </p>
                            </div>
                        </a>
                    <?php else: ?>
                        <div class="vironeer-notification">
                            <div class="vironeer-notification-image">
                                <img src="<?php echo e($notification->image); ?>" alt="<?php echo e($notification->title); ?>">
                            </div>
                            <div class="vironeer-notification-info">
                                <p
                                    class="vironeer-notification-title mb-0 d-flex justify-content-between align-items-center">
                                    <span><?php echo e(shorterText($notification->title, 30)); ?></span>
                                    <?php if(!$notification->status): ?>
                                        <span class="unread flashit"><i class="fas fa-circle"></i></span>
                                    <?php endif; ?>
                                </p>
                                <p class="vironeer-notification-text mb-0">
                                    <?php echo e($notification->created_at->diffforhumans()); ?>

                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty">
                        <small class="text-muted mb-0"><?php echo e(admin_trans('No notifications found')); ?></small>
                    </div>
                <?php endif; ?>
            </div>
            <a class="vironeer-notifications-footer" href="<?php echo e(route('admin.notifications.index')); ?>">
                <?php echo e(admin_trans('View All')); ?>

            </a>
        </div>
    </div>

    <div class="vironeer-user-menu">
        <div class="vironeer-user" id="dropdownMenuButton" data-bs-toggle="dropdown">
            <div class="vironeer-user-avatar">
                <img src="<?php echo e(auth()->user()->getAvatar()); ?>" alt="<?php echo e(auth()->user()->getName()); ?>" />
            </div>
            <div class="vironeer-user-info d-none d-md-block">
                <p class="vironeer-user-title mb-0"><?php echo e(auth()->user()->getName()); ?></p>
                <p class="vironeer-user-text mb-0"><?php echo e(auth()->user()->email); ?></p>
            </div>
        </div>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <li><a class="dropdown-item" href="<?php echo e(route('admin.account.index')); ?>">
                    <i class="fa-solid fa-user-pen me-1"></i>
                    <?php echo e(admin_trans('Account')); ?>

                </a>
            </li>
            <li>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="dropdown-item text-danger"><i
                            class="fas fa-sign-out-alt me-2"></i><?php echo e(admin_trans('Logout')); ?></button>
                </form>
            </li>
        </ul>
    </div>
</header>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/includes/navbar.blade.php ENDPATH**/ ?>
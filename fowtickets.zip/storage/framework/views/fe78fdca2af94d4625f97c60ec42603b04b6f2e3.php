<!DOCTYPE html>
<html lang="<?php echo e(getLocale()); ?>" dir="<?php echo e(getDirection()); ?>">

<head>
    <?php $__env->startPush('styles_libs'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/simplebar/simplebar.min.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('user.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="section py-5">
        <div class="container">
            <div class="section-header text-start">
                <div class="row row-cols-auto align-items-center justify-content-between g-2">
                    <div class="col">
                        <h2><?php echo $__env->yieldContent('title'); ?></h2>
                        <?php echo $__env->make('partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <?php if (! empty(trim($__env->yieldContent('back')))): ?>
                        <div class="col">
                            <a href="<?php echo $__env->yieldContent('back'); ?>" class="btn btn-outline-secondary btn-md">
                                <i
                                    class="fa-solid fa-arrow-<?php echo e(config('app.direction') == 'rtl' ? 'right' : 'left'); ?> me-2"></i>
                                <?php echo e(translate('Back', 'tickets')); ?>

                            </a>
                        </div>
                    <?php endif; ?>
                    <?php if(request()->routeIs('user.tickets.index')): ?>
                        <div class="col">
                            <a href="<?php echo e(route('user.tickets.create')); ?>" class="btn btn-primary btn-md">
                                <i class="fa fa-plus me-1"></i>
                                <?php echo e(translate('New Ticket', 'tickets')); ?>

                            </a>
                        </div>
                    <?php endif; ?>
                    <?php if(request()->routeIs('user.notifications.index')): ?>
                        <div class="col">
                            <a href="<?php echo e(route('user.notifications.read.all')); ?>"
                                class="btn btn-outline-primary btn-md action-confirm me-2"><i
                                    class="fa-regular fa-bookmark me-2"></i><?php echo e(translate('Mark All as Read', 'notifications')); ?></a>
                            <form action="<?php echo e(route('user.notifications.destroy.all')); ?>" method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-outline-danger action-confirm btn-md"><i
                                        class="fa-regular fa-trash-can me-2"></i><?php echo e(translate('Delete All Read', 'notifications')); ?></button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="section-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.config', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('scripts_libs'); ?>
        <script src="<?php echo e(asset('assets/vendor/libs/simplebar/simplebar.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
    <?php echo $__env->make('includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/user/layouts/app.blade.php ENDPATH**/ ?>
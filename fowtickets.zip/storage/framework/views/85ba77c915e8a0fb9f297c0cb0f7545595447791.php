<?php $__env->startSection('section', admin_trans('Members')); ?>
<?php $__env->startSection('title', admin_trans('Admins')); ?>
<?php $__env->startSection('link', route('admin.members.admins.create')); ?>
<?php $__env->startSection('content'); ?>
    <div class="custom-card card">
        <div class="card-header p-3 border-bottom-small">
            <form action="<?php echo e(request()->url()); ?>" method="GET">
                <div class="row g-3">
                    <div class="col-12 col-lg-10">
                        <input type="text" name="search" class="form-control" placeholder="<?php echo e(admin_trans('Search...')); ?>"
                            value="<?php echo e(request()->input('search') ?? ''); ?>">
                    </div>
                    <div class="col">
                        <button class="btn btn-primary w-100"><i class="fa fa-search"></i></button>
                    </div>
                    <div class="col">
                        <a href="<?php echo e(route('admin.members.admins.index')); ?>"
                            class="btn btn-secondary w-100"><?php echo e(admin_trans('Reset')); ?></a>
                    </div>
                </div>
            </form>
        </div>
        <div>
            <?php if($admins->count() > 0): ?>
                <div class="table-responsive">
                    <table class="vironeer-normal-table table w-100">
                        <thead>
                            <tr>
                                <th class="tb-w-3x">#</th>
                                <th class="tb-w-20x"><?php echo e(admin_trans('Admin details')); ?></th>
                                <th class="tb-w-3x text-center"><?php echo e(admin_trans('Added date')); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($admin->id); ?></td>
                                    <td>
                                        <div class="vironeer-user-box">
                                            <a class="vironeer-user-avatar"
                                                href="<?php echo e(route('admin.members.admins.edit', $admin->id)); ?>">
                                                <img src="<?php echo e($admin->getAvatar()); ?>" class="rounded-circle"
                                                    alt="<?php echo e($admin->getName()); ?>" />
                                            </a>
                                            <div>
                                                <a class="text-reset"
                                                    href="<?php echo e(route('admin.members.admins.edit', $admin->id)); ?>"><?php echo e($admin->getName()); ?></a>
                                                <p class="text-muted mb-0"><?php echo e($admin->email); ?></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center"><?php echo e(dateFormat($admin->created_at)); ?></td>
                                    <td>
                                        <div class="text-end">
                                            <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown"
                                                aria-expanded="true">
                                                <i class="fa fa-ellipsis-v fa-sm text-muted"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-sm-end"
                                                data-popper-placement="bottom-end">
                                                <li>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('admin.members.admins.edit', $admin->id)); ?>"><i
                                                            class="fas fa-edit me-2"></i><?php echo e(admin_trans('Edit')); ?></a>
                                                </li>
                                                <li>
                                                    <hr class="dropdown-divider" />
                                                </li>
                                                <li>
                                                    <form action="<?php echo e(route('admin.members.admins.destroy', $admin->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                        <button class="action-confirm dropdown-item text-danger"><i
                                                                class="far fa-trash-alt me-2"></i><?php echo e(admin_trans('Delete')); ?></button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <?php echo $__env->make('admin.partials.empty', ['size' => 180], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
    <?php echo e($admins->links()); ?>

    <?php $__env->startPush('styles_libs'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts_libs'); ?>
        <script src="<?php echo e(asset('assets/vendor/libs/bootstrap/select/bootstrap-select.min.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/members/admins/index.blade.php ENDPATH**/ ?>
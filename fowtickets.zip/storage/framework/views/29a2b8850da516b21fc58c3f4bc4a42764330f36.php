<?php if($oauthProviders->count() > 0): ?>
    <div class="login-with mt-3">
        <div class="login-with-divider">
            <span><?php echo e(translate('Or With', 'auth')); ?></span>
        </div>
        <div class="row g-3">
            <?php $__currentLoopData = $oauthProviders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oauthProvider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-xl">
                    <a href="<?php echo e(route('oauth.login', $oauthProvider->alias)); ?>"
                        class="btn btn-<?php echo e($oauthProvider->alias); ?> btn-md w-100 text-center">
                        <i class="<?php echo e($oauthProvider->icon); ?> me-2"></i> <?php echo e(translate($oauthProvider->name, 'auth')); ?>

                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/components/oauth-buttons.blade.php ENDPATH**/ ?>
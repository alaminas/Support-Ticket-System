<!DOCTYPE html>
<html lang="<?php echo e(getLocale()); ?>" dir="<?php echo e(getDirection()); ?>">

<head>
    <?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="vironeer-page-content">
        <?php echo $__env->make('admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container <?php echo $__env->yieldContent('container'); ?>">
            <div class="vironeer-page-body px-1 px-sm-2 px-xxl-0">
                <div class="py-4 g-4">
                    <div class="row align-items-center">
                        <div class="col">
                            <?php echo $__env->make('admin.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-auto">
                            <?php if (! empty(trim($__env->yieldContent('back')))): ?>
                                <a href="<?php echo $__env->yieldContent('back'); ?>" class="btn btn-secondary me-2"><i
                                        class="fas fa-arrow-left fa-rtl me-2"></i><?php echo e(admin_trans('Back')); ?></a>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('link')))): ?>
                                <a href="<?php echo $__env->yieldContent('link'); ?>" class="btn btn-dark me-2"><i class="fa fa-plus"></i></a>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('modal')))): ?>
                                <button type="button" class="btn btn-dark me-2" data-bs-toggle="modal"
                                    data-bs-target="#viewModal">
                                    <?php echo $__env->yieldContent('modal'); ?>
                                </button>
                            <?php endif; ?>
                            <button form="vironeer-submited-form" class="btn btn-primary <?php echo $__env->yieldContent('btn_action'); ?>"
                                <?php echo $__env->yieldContent('btn_action'); ?>><?php echo e(admin_trans('Save')); ?></button>
                        </div>
                    </div>
                </div>
                <div class="vironeer-form-page">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('admin.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/admin/layouts/form.blade.php ENDPATH**/ ?>
<footer class="footer-sm">
    <div class="<?php echo e($container ?? 'container'); ?>">
        <div class="row justify-content-between g-3">
            <div class="col-auto">
                <div class="footer-copyright">
                    <p class="mb-0">&copy; <span data-year></span>
                        <?php echo e($settings->general->site_name); ?> - <?php echo e(translate('All rights reserved')); ?>.</p>
                </div>
            </div>
            <?php if($footerMenuLinks->count() > 0): ?>
                <div class="col-auto">
                    <div class="footer-links">
                        <?php $__currentLoopData = $footerMenuLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footerMenuLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="link">
                                <a href="<?php echo e($footerMenuLink->link); ?>"><?php echo e($footerMenuLink->name); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</footer>
<?php /**PATH C:\wamp64\www\fowtickets\resources\views/includes/footer.blade.php ENDPATH**/ ?>
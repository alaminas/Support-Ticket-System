<?php $__env->startSection('title', translate('New ticket', 'tickets')); ?>
<?php $__env->startSection('back', route('user.tickets.index')); ?>
<?php $__env->startSection('content'); ?>
    <div class="card-v">
        <form action="<?php echo e(route('user.tickets.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row g-4 mb-4">
                <div class="col-lg-12">
                    <label class="form-label"><?php echo e(translate('Subject', 'tickets')); ?></label>
                    <input type="text" name="subject" class="form-control form-control-md" value="<?php echo e(old('subject')); ?>"
                        autofocus required>
                </div>
                <div class="col-lg-6">
                    <label class="form-label"><?php echo e(translate('Department', 'tickets')); ?></label>
                    <select name="department" class="form-select form-select-md" required>
                        <option value="" disabled selected><?php echo e(translate('Choose', 'tickets')); ?></option>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department->id); ?>"
                                <?php echo e(old('department') == $department->id ? 'selected' : ''); ?>><?php echo e($department->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-lg-6">
                    <label class="form-label"><?php echo e(translate('Priority', 'tickets')); ?></label>
                    <select name="priority" class="form-select form-select-md" required>
                        <?php $__currentLoopData = \App\Models\Ticket::getPriorityOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e(old('priority') == $key ? 'selected' : ''); ?>>
                                <?php echo e($value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-lg-12">
                    <label class="form-label"><?php echo e(translate('Description', 'tickets')); ?></label>
                    <textarea name="description" class="form-control" rows="10" required><?php echo e(old('description')); ?></textarea>
                </div>
                <div class="col-lg-12">
                    <div class="attachments">
                        <div class="attachment-box-1">
                            <label class="form-label"><?php echo e(translate('Attachments', 'tickets')); ?>

                                (<?php echo e($settings->tickets->file_types); ?>) </label>
                            <div class="input-group">
                                <input type="file" name="attachments[]" class="form-control form-control-md">
                                <button id="addAttachment" class="btn btn-outline-secondary" type="button">
                                    <i class="fa fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button class="btn btn-primary btn-md"><?php echo e(translate('Submit', 'tickets')); ?></button>
        </form>
    </div>
    <?php $__env->startPush('top_scripts'); ?>
        <script>
            "use strict";
            const ticketsConfig = <?php echo json_encode([
                'max_file' => $settings->tickets->max_files,
                'max_files_error' => str(translate('Max {max} files can be uploaded', 'tickets'))->replace(
                    '{max}',
                    $settings->tickets->max_files,
                ),
            ]); ?>

        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\fowtickets\resources\views/user/tickets/create.blade.php ENDPATH**/ ?>
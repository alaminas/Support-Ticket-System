<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\fowtickets\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>
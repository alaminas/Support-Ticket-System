<?php

return array(
    'reset' => 'Your password has been reset!',
    'sent' => 'We have emailed your password reset link!',
    'throttled' => 'Please wait before retrying.',
    'token' => 'This password reset token is invalid.',
    'user' => 'We can\'t find a user with that email address.',
    'not_matches_with_the_password_you_provided' => 'Your current password does not matches with the password you provided',
    'new_password_cannot_be_same_as_your_current_password_please_choose_a_different_password' => 'New Password cannot be same as your current password. Please choose a different password',
);

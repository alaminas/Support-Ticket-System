<?php 
 return array (
  'all_rights_reserved' => 'All rights reserved',
  'gdpr_cookie_note' => 'We use cookies to personalize your experience. By continuing to visit this website you agree to our use of cookies',
  'got_it' => 'Got it',
  'more' => 'More',
  'cookie_accepted_successfully' => 'Cookie accepted successfully',
  'copied_to_clipboard' => 'Copied to clipboard',
  'close' => 'Close',
  'are_you_sure' => 'Are you sure?',
);
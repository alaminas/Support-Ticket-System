<?php

return array(
    'how_we_can_help_you' => 'How We Can Help You?',
    'start_searching_to_find_answers_or_check_our_knowledge_base' => 'Start searching to find answers, or check our knowledge base',
    'knowledge_base' => 'Knowledge Base',
    'knowledge_base_description' => 'Our comprehensive knowledge base offers a centralized hub of valuable information, guides, and solutions designed to empower and assist users. Access a wide range of topics.',
    'still_no_luck_we_can_help' => 'Still no luck? We can help!',
    'open_a_ticket_and_we_will_contact_you_back_as_soon_as_possible' => 'Open a ticket and we will contact you back as soon as possible.',
    'open_a_ticket' => 'Open a ticket',
);

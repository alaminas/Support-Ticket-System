<?php

return array (
  'name' => 'Name',
  'email' => 'Email',
  'subject' => 'Subject',
  'message' => 'Message',
  'send' => 'Send',
  'sending_emails_is_not_available_right_now' => 'Sending emails is not available right now',
  'sending_failed' => 'Sending failed',
  'your_message_has_been_sent_successfully' => 'Your message has been sent successfully',
);

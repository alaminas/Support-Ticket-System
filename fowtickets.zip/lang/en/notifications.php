<?php

return array (
  'notifications' => 'Notifications',
  'mark_all_as_read' => 'Mark All as Read',
  'delete_all_read' => 'Delete All Read',
  'deleted_successfully' => 'Deleted Successfully',
  'view_all' => 'View All',
  'all_notifications_marked_as_read_successfully' => 'All notifications marked as read successfully',
  'no_notifications_found' => 'No notifications found',
  'new_ticket_created_number' => 'New Ticket Created #{number}',
  'new_reply_on_ticket_number' => 'New Reply On Ticket #{number}',
);

<?php

return array(
    'first_name' => 'First Name',
    'last_name' => 'Last Name',
    'email_address' => 'Email address',
    'password' => 'Password',
    'confirm_password' => 'Confirm password',
    'new_password' => 'New Password',
    'confirm_new_password' => 'Confirm New Password',
    'otp_code' => 'OTP Code',
);
